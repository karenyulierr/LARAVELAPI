# Flutter Real-Time Location Updates

This is a very basic implementation of a location-based application that handles user's location changes in real-time.

## Reference
Medium Article

https://medium.com/@romanejaquez/implement-real-time-location-updates-on-google-maps-in-flutter-235c8a09173e

Please follow the instructions in the following dependency packages:
Google Maps Flutter (https://pub.dev/packages/google_maps_flutter)
Flutter Polyline Points (https://pub.dev/packages/flutter_polyline_points)
Flutter Location Plugin (https://pub.dev/packages/location)


Thanks!


