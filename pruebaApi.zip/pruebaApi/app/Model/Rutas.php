<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Rutas extends Model
{
    public $table = "rutas";

    protected $fillable = [
        'codigo',
        'descripcion',
        'estado',
        'fechaCrea',
        'fechaModifica',
        'idUsuarioCrea',
        'idUsuarioModifica',
        'rutaIniLatitud',
        'rutaFinLongitud',
        'rutaIniLongitud',
        'rutaFinLatitud'
    ];

    public $timestamps = false;
}
